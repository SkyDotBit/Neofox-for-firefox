# Neofox for chromium (Neofoxify)
:neofox_floof:
Replaces all Neofox names like ":neofox_floof:" with actual Neofoxes :neofox:
Only works on sites not listed in the [blacklist](https://skydevs.me/assets/neofox/blacklist.txt).

## Credits :neofox_mug_drink:
- [Volpeon](https://volpeon.ink/) - Made Neofox emojis along with many other amazing emojis!
- [Me](https://skydevs.me) - Made the extension :neofox_floof: